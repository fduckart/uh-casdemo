package edu.hawaii.its.casdemo.service;

public interface AdministratorService {
    public boolean exists(String uhuuid);
}
