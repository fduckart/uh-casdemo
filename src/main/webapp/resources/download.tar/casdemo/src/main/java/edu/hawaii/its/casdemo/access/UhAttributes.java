package edu.hawaii.its.casdemo.access;

public interface UhAttributes {
    public String getValue(String name);
}
