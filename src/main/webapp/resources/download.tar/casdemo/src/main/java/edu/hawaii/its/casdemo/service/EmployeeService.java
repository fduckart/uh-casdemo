package edu.hawaii.its.casdemo.service;

public interface EmployeeService {
    public boolean exists(String uhuuid);
}
