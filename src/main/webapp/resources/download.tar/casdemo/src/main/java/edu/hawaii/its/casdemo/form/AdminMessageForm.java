package edu.hawaii.its.casdemo.form;

public class AdminMessageForm {

    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}
